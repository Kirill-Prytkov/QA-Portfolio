#!/bin/bash

docker exec -e PGPASSWORD=examplepass db psql -U exampleuser -d exampledb -c 'explain analyze SELECT * FROM "user";' 

sleep 100