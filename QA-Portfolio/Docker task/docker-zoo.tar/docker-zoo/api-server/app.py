from flask import Flask, request, jsonify

app = Flask(__name__)

# Фейковая база пользователей (словарь вместо PostgreSQL)
users = {
    "b8fdcfd9-df41-4f94-a53f-8e1dff3abf97": {"name": "Иван Медведев", "signing_enabled": False},
    "4e4b39e9-fe7b-4115-b7c8-fca8ef7c9113": {"name": "Кузьма Кашин", "signing_enabled": True},
    "ecc63925-8f5d-4dc4-bf6c-7a06ce880d6a": {"name": "Нестор Гаврилов", "signing_enabled": False},
}

@app.route("/api/v1/users/<user_id>/signing/enable", methods=["PUT"])
def enable_signing(user_id):
    if user_id not in users:
        return jsonify({"error": "User not found"}), 404
    
    users[user_id]["signing_enabled"] = True
    return jsonify({"message": f"Signing enabled for user {user_id}", "user": users[user_id]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)  # Запускаем сервер на 5000 порту
