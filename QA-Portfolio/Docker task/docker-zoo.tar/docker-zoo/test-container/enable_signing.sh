#!/bin/bash

set -x
sqlid=$(PGPASSWORD=examplepass db psql -h db -U exampleuser -d exampledb -t -c 'SELECT id FROM "user" WHERE signing_enabled = false;')


for id in $sqlid; do
    curl -X PUT "http://172.18.0.4:5000/api/v1/users/$id/signing/enable"
done